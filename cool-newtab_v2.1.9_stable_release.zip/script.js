const btn = document.getElementById('searchBtn');
const tilesContainer = document.getElementById('tilesContainer');
const popupOverlay = document.getElementById('popupOverlay');
const editTitle = document.getElementById('editTitle');
const editLink = document.getElementById('editLink');
const saveBtn = document.getElementById('saveBtn');
const cancelBtn = document.getElementById('cancelBtn');
const manageToggle = document.getElementById('manageToggle');
const bodya = document.getElementById('bodya');
const bodyb = document.getElementById('bodyb');
const wallpaperBtn = document.getElementById('wallpaperBtn');
const settingsBtn = document.getElementById('settingsBtn');
const wallpaperPopup = document.getElementById('wallpaperPopup');
const settingsPopup = document.getElementById('settingsPopup');
const chooseWallpaperBtn = document.getElementById('chooseWallpaperBtn');
const cancelWallpaperBtn = document.getElementById('cancelWallpaperBtn');
const settingscloseBtn = document.getElementById('settingscloseBtn');
const wallpaperInput = document.getElementById('wallpaperInput');
const clockToggle = document.getElementById('clockFormatToggle');
const wallpaperToggle = document.getElementById('wallpaperToggle');
const bookmarksuggestionsToggle = document.getElementById('bookmarksuggestionsToggle');
const wall = document.getElementById('wall');
const backtomainpopupbtn = document.getElementById('backtomainpopupbtn');
const pluginsettingsbtn = document.getElementById('pluginSettingsBtn');
const managepluginbtn = document.getElementById('managepluginBtn');
const selectedText = document.getElementById('selectedText');
const selectedSearch = document.getElementById('selectedSearch');
const currentIcon = selectedSearch.querySelector('img');
const searchOptions = document.getElementById('searchOptions');



function openWallpaperDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('WallpaperDB', 3);
    request.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('wallpapers')) {
        db.createObjectStore('wallpapers');
      }
    };
    request.onsuccess = e => resolve(e.target.result);
    request.onerror = e => reject(e.target.error);
  });
}

async function saveWallpaperBlob(blob) {
  const db = await openWallpaperDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('wallpapers', 'readwrite');
    const store = tx.objectStore('wallpapers');
    store.put(blob, 'currentWallpaper');
    store.put(blob.type, 'wallpaperType');
    tx.oncomplete = () => resolve();
    tx.onerror = e => reject(e.target.error);
  });
}

async function loadWallpaperBlob() {
  const db = await openWallpaperDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('wallpapers', 'readonly');
    const store = tx.objectStore('wallpapers');

    const getBlob = store.get('currentWallpaper');
    const getType = store.get('wallpaperType');

    let blob = null;
    let type = '';

    let blobDone = false;
    let typeDone = false;

    function checkDone() {
      if (blobDone && typeDone) {
        resolve({ blob, type });
      }
    }

    getBlob.onsuccess = () => {
      blob = getBlob.result || null;
      blobDone = true;
      checkDone();
    };
    getBlob.onerror = () => reject(getBlob.error);

    getType.onsuccess = () => {
      type = getType.result || '';
      typeDone = true;
      checkDone();
    };
    getType.onerror = () => reject(getType.error);

    tx.onerror = e => reject(e.target.error);
  });
}

function ensureWallDiv() {
  let wall = document.getElementById('wall');
  if (!wall) {
    wall = document.createElement('div');
    wall.id = 'wall';
    wall.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;z-index:-1;overflow:hidden;';
    document.body.appendChild(wall);
  }
  return wall;
}

function applyWallpaper(url, fileType = '') {
  const wall = ensureWallDiv();
  wall.innerHTML = '';

  const overlay = document.getElementById('bodya');
  if (!overlay) console.warn('Missing #overlay element');

  const isVideo = fileType.startsWith('video/') || /\.(mp4|webm|ogg)$/i.test(url);
  const isImage = fileType.startsWith('image/') || /\.(png|jpe?g|gif|bmp|webp|svg)$/i.test(url);
  const isHTML = fileType === 'text/html' || /\.html?$/i.test(url);
  const isPDF = fileType === 'application/pdf' || /\.pdf$/i.test(url);

  if (isVideo) {
    const video = document.createElement('video');
    video.src = url;
    video.autoplay = true;
    video.loop = true;
    video.muted = true;
    video.playsInline = true;
    video.style.cssText = 'width:100%;height:100%;object-fit:cover;';
    wall.appendChild(video);
    if (overlay) overlay.style.display = 'block';
  } else if (isImage) {
    const img = document.createElement('img');
    img.src = url;
    img.style.cssText = 'width:100%;height:100%;object-fit:cover;';
    wall.appendChild(img);
    if (overlay) overlay.style.display = 'block';
  } else if (isHTML || isPDF) {
    const iframe = document.createElement('iframe');
    iframe.src = url;
    iframe.style.cssText = 'border:none;position:fixed;top:0;left:0;width:100%;height:100%;z-index:-1;';
    wall.appendChild(iframe);

    if (overlay) overlay.style.display = isHTML ? 'none' : 'block';

    iframe.addEventListener('focus', () => {
      if (typeof renderTiles === 'function') renderTiles();
    });
    iframe.addEventListener('click', () => {
      if (typeof renderTiles === 'function') renderTiles();
    });
  } else {
    console.warn('Unsupported wallpaper type:', fileType);
    if (overlay) overlay.style.display = 'block';
  }
}

wallpaperInput.onchange = async () => {
  const file = wallpaperInput.files[0];
  if (!file) return;

  if (file.size > MAX_SIZE) {
    alert('File too large! Max 200MB.');
    wallpaperInput.value = '';
    return;
  }

  try {
    await saveWallpaperBlob(file);
    applyWallpaper(URL.createObjectURL(file), file.type);

    wallpaperPopup.style.display = 'none';

    editMode = !editMode;
    manageToggle.setAttribute('aria-pressed', editMode);
    if (typeof renderTiles === 'function') renderTiles();
  } catch (e) {
    alert('Failed to save wallpaper: ' + e.message);
  }
};

async function initWallpaper() {
  try {
    const { blob, type } = await loadWallpaperBlob();
    if (blob) {
      applyWallpaper(URL.createObjectURL(blob), type);
    } else {
      applyWallpaper('./assets/defwall.webp', 'image/webp');
    }
  } catch (err) {
    applyWallpaper('./assets/defwall.webp', 'image/webp');
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initWallpaper);
} else {
  initWallpaper();
}




history.replaceState(null, "", "/newtab");


const loadedVersion = localStorage.latest;

setInterval(() => {
  if (localStorage.latest !== loadedVersion) {
    window.location.replace("newtab.html");
  }
}, 100);

 window.addEventListener('keydown', function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'r') {
      e.preventDefault();
      alert("Newtabs are temporary pages, aren't meant to be reloaded. Open another Newtab or press CRTL + T instad 😊");
    }
  });

    const fallbackSrc = 'assets/favicon_newtabpage.png';

  function getRandomHue() {
    return `hue-rotate(${Math.floor(Math.random() * 360)}deg)`;
  }

  function fixImages() {
    document.querySelectorAll('img:not(#wall img)').forEach(img => {
      const applyFallback = () => {
        img.onerror = null;
        img.src = fallbackSrc;
        img.style.filter = getRandomHue();
      };

      if (!img.src || img.src.trim() === '') {
        applyFallback();
      } else if (img.naturalWidth === 0) {
        applyFallback();
      }

      img.onerror = applyFallback;
    });
  }

  window.addEventListener('load', fixImages);
  setInterval(fixImages, 500);


  (function () {
  try {
    const settings = JSON.parse(localStorage.getItem('ntabsettings'));
    if (
      settings &&
      typeof settings === 'object' &&
      ('newtabclockform' in settings) &&
      ('wallpaperEnabled' in settings)&&
      ('bookmarksuggestions' in settings)
    ) {
      return;
    }
  } catch {}

  const defaultSettings = {
    newtabclockform: '12',
    wallpaperEnabled: true,
    bookmarksuggestions: true

  };
  localStorage.setItem('ntabsettings', JSON.stringify(defaultSettings));
})();

let currentEditIndex = null;
let editMode = false;
let isAddingNew = false;
setTimeout(() => {
  if (!document.getElementById('bookmarkcustom')){localStorage.MAX_BOOKMARKS = 10};
}, 1000); 

if (!localStorage.MAX_BOOKMARKS){localStorage.MAX_BOOKMARKS = 10};
const MAX_SIZE = 2000 * 1024 * 1024; // 200 MB max size for wallpaper file


function extractDomain(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return '';
  }
}

function getFavicon(domain) {
  const key = `favicon_${domain}`;
  const cached = localStorage.getItem(key);
  if (cached) return cached;

  const proxyUrl = `https://heckthetech.vercel.app/api/favfetch?fetch=${domain}`;

  // Preload and cache favicon
  fetch(proxyUrl)
    .then(res => res.text())
    .then(dataURI => {
      if (dataURI.startsWith('data:image')) {
        localStorage.setItem(key, dataURI);
        renderTiles(); // re-render after loading new favicon
      }
    })
    .catch(() => {});

  // Return empty (fallback) while loading
  return '';
}

function loadBookmarks() {
  const data = localStorage.getItem('bookmarks');
  return data ? JSON.parse(data) : [];
}

function saveBookmarks(bookmarks) {
  localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
}

function ensureProtocol(url) {
  return url.match(/^https?:\/\//i) ? url : 'https://' + url;
}

function renderTiles() {

document.getElementById("suggestions").innerHTML="";
  wallpaperBtn.style.display = editMode ? 'flex' : 'none';
  settingsBtn.style.display = editMode ? 'flex' : 'none';
  


  tilesContainer.innerHTML = '';
  const bookmarks = loadBookmarks();

setTimeout(() => {
  if (!document.getElementById('layoutcustom')){localStorage.layoutPattern = '3, 4, 3';};
}, 1000); 
 if (!localStorage.layoutPattern){localStorage.layoutPattern = '3, 4, 3';};

  let dataIndex = 0;

  localStorage.layoutPattern.split(',').map(Number).forEach(rowCount => {
    const row = document.createElement('div');
    row.style.display = 'flex';
    row.style.justifyContent = 'center';

    for (let i = 0; i < rowCount && dataIndex < bookmarks.length; i++) {
      const index = dataIndex;
      const bookmark = bookmarks[dataIndex++];
      const domain = bookmark.link;
      const tileContainer = document.createElement('div');
      tileContainer.className = 'tile-container';
      tileContainer.dataset.index = index;if (editMode) tileContainer.setAttribute('draggable', 'true');
else tileContainer.removeAttribute('draggable');


      tileContainer.innerHTML = `
        <a href="${bookmark.link}" class="tile" draggable="false">
          <img src="${getFavicon(domain)}" />
          <span class="tile-title">${bookmark.title}</span>
        </a>
<div class="edit-btn" title="Edit bookmark" aria-label="Edit bookmark" tabindex="0" style="display: none;">
            <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 6l2.293-2.293a1 1 0 0 1 1.414 0l2.586 2.586a1 1 0 0 1 0 1.414L18 10
                   M14 6l-9.707 9.707a1 1 0 0 0-.293.707V19a1 1 0 0 0 1 1h2.586a1 1 0 0 0 
                   .707-.293L18 10m-4-4l4 4"></path>
            </svg>
          </div>
        <div class="delete-btn" title="Delete" tabindex="0">×</div>
      `;

      row.appendChild(tileContainer);
    }

    tilesContainer.appendChild(row);
  });

  // Add tile button if in edit mode
  if (editMode && bookmarks.length < localStorage.MAX_BOOKMARKS) {
    const addBtn = document.createElement('div');
    addBtn.className = 'add-tile-container';
    addBtn.innerHTML = `<div class="add-tile" title="Add new" tabindex="0">+</div>`;
    tilesContainer.appendChild(addBtn);
  }

  if (editMode) {
    tilesContainer.classList.add('edit-mode');
    document.querySelectorAll('.edit-btn').forEach(btn => {
      btn.style.display = 'flex';
      btn.onclick = e => { e.stopPropagation(); openEditPopup(+btn.parentElement.dataset.index); };
    });
    document.querySelectorAll('.delete-btn').forEach(btn => {
      btn.style.display = 'flex';
      btn.onclick = e => { e.stopPropagation(); deleteBookmark(+btn.parentElement.dataset.index); };
    });
    const addBtn = document.querySelector('.add-tile');
    if (addBtn) addBtn.onclick = openAddPopup;
  } else {
    tilesContainer.classList.remove('edit-mode');
    document.querySelectorAll('.edit-btn, .delete-btn, .add-tile','.settings-btn').forEach(btn => {
      btn.style.display = 'none';
      btn.onclick = null;
    });  }
setTimeout(fixImages,100);
  };


function openEditPopup(index) {
  currentEditIndex = index;
  isAddingNew = false;
  const bm = loadBookmarks()[index];
  editTitle.value = bm.title;
  editLink.value = bm.link;
  popupOverlay.style.display = 'flex';
  editTitle.focus();
}

function openAddPopup() {
  if (loadBookmarks().length >= localStorage.MAX_BOOKMARKS) return;
  isAddingNew = true;
  editTitle.value = '';
  editLink.value = '';
  popupOverlay.style.display = 'flex';
  editTitle.focus();
}

function closeEditPopup() {
  popupOverlay.style.display = 'none';
  currentEditIndex = null;
  isAddingNew = false;
}

function deleteBookmark(index) {
  const bookmarks = loadBookmarks();
  const [removed] = bookmarks.splice(index, 1);
  saveBookmarks(bookmarks);
  if (removed) localStorage.removeItem(`favicon_${removed.link}`);
  editMode = false;
  manageToggle.setAttribute('aria-pressed', 'false');
  renderTiles();
}

manageToggle.addEventListener('click', () => {
  editMode = !editMode;
  manageToggle.setAttribute('aria-pressed', editMode);
  renderTiles();
});

saveBtn.addEventListener('click', () => {
  const titleVal = editTitle.value.trim();
  let linkVal = ensureProtocol(editLink.value.trim());
  if (!titleVal || !linkVal) return alert('Both fields are required!');
  const bookmarks = loadBookmarks();

  if (isAddingNew) {
    if (bookmarks.length >= localStorage.MAX_BOOKMARKS) return alert(`Max ${localStorage.MAX_BOOKMARKS} bookmarks.`);
    bookmarks.push({ title: titleVal, link: linkVal });
  } else if (currentEditIndex != null) {
    bookmarks[currentEditIndex] = { title: titleVal, link: linkVal };
  }

  saveBookmarks(bookmarks);
  editMode = false;
  manageToggle.setAttribute('aria-pressed', 'false');
  renderTiles();
  closeEditPopup();
});

cancelBtn.onclick = closeEditPopup;
bodya.onclick = () => { editMode = false; manageToggle.setAttribute('aria-pressed', 'false');renderTiles();};
bodyb.onclick = () => {document.getElementById("suggestions").innerHTML="";};
popupOverlay.onclick = e => { if (e.target === popupOverlay) closeEditPopup(); };

if (!localStorage.getItem('bookmarks')) {
  saveBookmarks([
    { title: "Youtube", link: "https://youtube.com" },
    { title: "Messenger", link: "https://messenger.com/t" },
    { title: "Whatsapp", link: "https://web.whatsapp.com" },
  ]);
}

renderTiles();
setTimeout(() => document.getElementById("load").style.display = "none", 100);

wallpaperBtn.onclick = () => wallpaperPopup.style.display = 'flex';
cancelWallpaperBtn.onclick = () => wallpaperPopup.style.display = 'none';
settingsBtn.onclick = () => {bodya.style.zIndex = '1000';bodya.style.background='rgb(0 0 0 / 80%)'; settingsPopup.style.display = 'flex';}
settingscloseBtn.onclick = () => {bodya.style.zIndex = '0';bodya.style.background='';settingsPopup.style.display = 'none'; editMode = false; manageToggle.setAttribute('aria-pressed', 'false'); renderTiles();};
  
chooseWallpaperBtn.onclick = () => wallpaperInput.click();

function updateClock() {
  const clockElem = document.getElementById('digitalClock');
  let fmt = '12';
  try { fmt = JSON.parse(localStorage.getItem('ntabsettings')).newtabclockform === '24' ? '24' : '12'; } catch {}
  const now = new Date();
  let h = now.getHours(), m = now.getMinutes(), ampm = '';
  if (fmt === '12') { ampm = h >= 12 ? ' PM' : ' AM'; h = h % 12 || 12; }
  clockElem.textContent = `${h < 10 ? '0'+h : h}:${m < 10 ? '0'+m : m}${ampm}`;

const settings = JSON.parse(localStorage.getItem('ntabsettings'));
const wallpaperEnabled = settings?.wallpaperEnabled !== false;  // show if true or undefined
wall.style.display = wallpaperEnabled ? '' : 'none';


}
updateClock();
setInterval(updateClock, 1000);


let dragSrcIndex = null;
let draggingElem = null;

tilesContainer.addEventListener('dragstart', e => {
  if (!editMode) return;
  const tile = e.target.closest('.tile-container');
  if (!tile) return;
  dragSrcIndex = +tile.dataset.index;
  draggingElem = tile;
  tile.classList.add('dragging');
  e.dataTransfer.effectAllowed = 'move';
});

tilesContainer.addEventListener('dragend', e => {
  if (draggingElem) draggingElem.classList.remove('dragging');
  document.querySelectorAll('.tile-container.drop-target').forEach(t => t.classList.remove('drop-target'));
  draggingElem = null;
});

tilesContainer.addEventListener('dragover', e => {
  if (!editMode) return;
  const target = e.target.closest('.tile-container');
  if (!target || target === draggingElem) return;
  e.preventDefault();
  document.querySelectorAll('.tile-container.drop-target').forEach(t => t.classList.remove('drop-target'));
  target.classList.add('drop-target');
  e.dataTransfer.dropEffect = 'move';
});

tilesContainer.addEventListener('dragleave', e => {
  const target = e.target.closest('.tile-container');
  if (target) target.classList.remove('drop-target');
});

tilesContainer.addEventListener('drop', e => {
  if (!editMode) return;
  const target = e.target.closest('.tile-container');
  if (!target || dragSrcIndex === null || target === draggingElem) return;

  const dropIndex = +target.dataset.index;
  if (dragSrcIndex === dropIndex) return;

  const bookmarks = loadBookmarks();
  const [moved] = bookmarks.splice(dragSrcIndex, 1);
  bookmarks.splice(dropIndex, 0, moved);
  saveBookmarks(bookmarks);
  renderTiles();
});


 (function () {
  try {
    const settings = JSON.parse(localStorage.getItem('ntabsettings'));
    if (
      settings &&
      typeof settings === 'object' &&
      ('newtabclockform' in settings) &&
      ('wallpaperEnabled' in settings)&&
      ('bookmarksuggestions' in settings)
    ) {
      return; // Already valid, do nothing
    }
  } catch {}

  // Create default if missing or corrupted
  const defaultSettings = {
    newtabclockform: '12',
    wallpaperEnabled: true,
    bookmarksuggestions: true

  };
  localStorage.setItem('ntabsettings', JSON.stringify(defaultSettings));
})();


function loadSettings() {
  const storedSearch = localStorage.getItem('searchEngine');
if (storedSearch) {
    selectedText.textContent = localStorage.getItem('searchEngineName') ;
    currentIcon.src = localStorage.getItem('searchEngineImage');
}

    try {
      const settings = JSON.parse(localStorage.getItem('ntabsettings')) || {};
      const clockFormat = settings.newtabclockform === '24' ? '24' : '12';
      const wallpaperEnabled = settings.wallpaperEnabled === true;
      const bookmarksuggestionsenabled = settings.bookmarksuggestions === true;

      clockToggle.checked = clockFormat === '24';
      wallpaperToggle.checked = wallpaperEnabled;
      bookmarksuggestionsToggle.checked = bookmarksuggestionsenabled;
    } catch {
      // Default fallback
      clockToggle.checked = false; // 12h by default
      wallpaperToggle.checked = true; // wallpaper on by default
     bookmarksuggestionsToggle.checked = true; // bookmarksuggestions on by default
    }
  }


loadSettings();



function generateTimestamp() {
  const now = new Date();
  const day = now.toLocaleDateString(undefined, { weekday: 'long' });
  return (
    now.getFullYear().toString() +
    (now.getMonth() + 1).toString().padStart(2, '0') +
    now.getDate().toString().padStart(2, '0') +
    now.getHours().toString().padStart(2, '0') +
    now.getMinutes().toString().padStart(2, '0') +
    now.getSeconds().toString().padStart(2, '0') +
    day
  );
}


selectedSearch.addEventListener('click', () => {
  searchOptions.style.display = (searchOptions.style.display === 'flex') ? 'none' : 'flex';
});

searchOptions.querySelectorAll('.search-option').forEach(option => {
  option.addEventListener('click', () => {
    const { url, name, icon } = option.dataset;

    selectedText.textContent = name;
    currentIcon.src = icon;

    localStorage.setItem('searchEngine', url);
    localStorage.setItem('searchEngineImage', `/assets/${name.toLowerCase()}.png`);
    localStorage.setItem('searchEngineName', name);
    localStorage.latest = generateTimestamp();
    searchOptions.style.display = 'none';
  });
});


// Click outside to close dropdown
document.addEventListener('click', e => {
  if (!document.getElementById('customSearchDropdown').contains(e.target)) {
    searchOptions.style.display = 'none';
  }
});



function saveSettings() {
  const newSettings = {
    newtabclockform: clockToggle.checked ? '24' : '12',
    wallpaperEnabled: wallpaperToggle.checked,
    bookmarksuggestions: bookmarksuggestionsToggle.checked
  };
  localStorage.setItem('ntabsettings', JSON.stringify(newSettings));
}

function saveSettingswithrefresh() {
  saveSettings();  localStorage.latest = generateTimestamp();

}

clockToggle.addEventListener('change', saveSettings);
wallpaperToggle.addEventListener('change', saveSettings);
bookmarksuggestionsToggle.addEventListener('change', saveSettingswithrefresh);




async function exportData() {
      const allData = {
        localStorage: { ...localStorage },
        indexedDB: {}
      };

      const dbs = await indexedDB.databases();
      for (const dbInfo of dbs) {
        if (!dbInfo.name) continue;
        const dbExport = await exportIndexedDB(dbInfo.name);
        allData.indexedDB[dbInfo.name] = dbExport;
      }

      const blob = new Blob([JSON.stringify(allData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'backup_data.heck';
      a.click();
      URL.revokeObjectURL(url);

      setTimeout(() => {
        window.close();
      }, 1000);
    }

    function exportIndexedDB(name) {
      return new Promise((resolve) => {
        const openRequest = indexedDB.open(name);
        openRequest.onsuccess = () => {
          const db = openRequest.result;
          const tx = db.transaction(db.objectStoreNames, 'readonly');
          const exportObject = {};
          let pendingStores = db.objectStoreNames.length;

          if (pendingStores === 0) return resolve({});

          for (const storeName of db.objectStoreNames) {
            const store = tx.objectStore(storeName);
            const getAll = store.getAll();
            getAll.onsuccess = () => {
              exportObject[storeName] = getAll.result;
              if (--pendingStores === 0) resolve(exportObject);
            };
            getAll.onerror = () => {
              exportObject[storeName] = [];
              if (--pendingStores === 0) resolve(exportObject);
            };
          }
        };
        openRequest.onerror = () => resolve({});
      });
    }

    async function importData(data) {
      for (const key in data.localStorage) {
        localStorage.setItem(key, data.localStorage[key]);
      }

      for (const dbName in data.indexedDB) {
        await importIndexedDB(dbName, data.indexedDB[dbName]);
      }

        localStorage.latest = generateTimestamp();
          setTimeout(() => {
        window.close();
      }, 100);

    }

    function importIndexedDB(name, dbData) {
      return new Promise((resolve) => {
        const req = indexedDB.open(name, 1);
        req.onupgradeneeded = () => {
          const db = req.result;
          for (const storeName in dbData) {
            if (!db.objectStoreNames.contains(storeName)) {
              db.createObjectStore(storeName, { autoIncrement: true });
            }
          }
        };
        req.onsuccess = () => {
          const db = req.result;
          const tx = db.transaction(Object.keys(dbData), 'readwrite');
          for (const storeName in dbData) {
            const store = tx.objectStore(storeName);
            for (const item of dbData[storeName]) {
              store.add(item);
            }
          }
          tx.oncomplete = () => resolve();
        };
        req.onerror = () => resolve();
      });
    }

    async function clearAllData() {
      localStorage.clear();
      indexedDB.databases().then(dbs => {
  dbs.forEach(db => {
    indexedDB.deleteDatabase(db.name);
  });
});
  localStorage.latest = generateTimestamp();

            setTimeout(() => {
        window.close();
      }, 100);

    }

    document.getElementById('exportBtn').onclick = exportData;
document.getElementById('reporter').onclick = () => window.open('http://heckthetech.github.io/report');
document.getElementById('heckabt').onclick = () => window.open('http://heckthetech.github.io/');

    document.getElementById('fileInput').addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const data = JSON.parse(reader.result);
          importData(data);
        } catch (err) {
          alert("Invalid file, make sure you have chosen correct .heck backup file!");
        }
      };
      reader.readAsText(file);
    });

    document.getElementById('clearBtn').onclick = () => {
      if (confirm("This will delete ALL data , Search History and Plugins. Continue?")) {
        clearAllData();
      }
    };
     managepluginbtn.onclick = () => {window.open('./html/plugin.html');};
 pluginSettingsBtn.onclick = () => {
      document.getElementById("mainPopup").style.display = "none";
      document.getElementById("pluginPopup").style.display = "flex";
    };
backtomainpopupbtn.onclick = () => {
      document.getElementById("mainPopup").style.display = "flex";
      document.getElementById("pluginPopup").style.display = "none";
    };

fetch('/manifest.json')
  .then(response => response.json())
  .then(data => {
    const versionElement = document.getElementById("version");
    const noteElement = document.getElementById("versionnote");

    if (versionElement) versionElement.textContent = data.version || "N/A Invalid";
    if (noteElement) noteElement.textContent = data.versionnote || "Invalid Source";
  })
  .catch(err => {
    console.error("Failed to load version data:", err);
  });

(async () => {
  const ALT_DB_NAME = "plugindata";
  const ALT_STORE_NAME = "plugins";
  const ALT_KEY_NAME = "all";

  // Check if DB exists
  if (!indexedDB.databases) return; // fallback for older browsers
  const dbs = await indexedDB.databases();
  const exists = dbs.some(db => db.name === ALT_DB_NAME);
  if (exists) return; // database already exists — do nothing

  // DB doesn't exist — create and populate
  function openDB_InjectMode() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(ALT_DB_NAME, 1);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(req.result);
      req.onupgradeneeded = e => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(ALT_STORE_NAME)) {
          db.createObjectStore(ALT_STORE_NAME);
        }
      };
    });
  }

  const pluginDump = `//pluginname{limits Adjuster}version{1.1}Author{Heck}

set override css = ^^
#bookmarkcustom{display:none;}
#layoutcustom{display:none;}
^^;

set localstorage.MAX_BOOKMARKS = 15;
set localstorage.layoutPattern = 5,5,5;

create div with id(#layoutcustom) ^^
on
^^;
create div with id(#bookmarkcustom) ^^
on
^^;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////pluginname{BetterTiles}version{1.0}Author{Heck}


set override css = ^^
  body {
    background: #666666 !important;
  }

.tile {
  position: relative !important;
    width: 100px !important;
    height: 90px !important;
    display: flex !important;
    align-items: center !important;
    padding-left: 15px !important;
    margin-left: 20px !important;
    gap: 10px !important;
    text-align: left !important;
}

.tile {
    background-color: #ffffff00 !important;
    padding: 15px 30px !important;
    border-radius: 20px !important;
    text-decoration: none !important;
    color: #fff !important;
    font-size: 1.1rem !important;
    font-weight: 500 !important;
    box-shadow: none !important;
    transition: background 0.3s ease, transform 0.2s ease !important;
    user-select: none; !important}

.tile img {
    width: auto !important;
    height: 60% !important;
    margin-left: 0 !important;
    flex-shrink: 0 !important;
    position: absolute !important;
    top: 5% !important;
    left: 30% !important;
}
.tile-title {
       white-space: nowrap !important;
    overflow: hidden !important;
    text-overflow: ellipsis !important;
    display: block !important;
    margin-bottom: -65px !important;
    min-width: 90px !important;
    max-width: 100px !important;    
    text-align: center !important;
    position: absolute !important;
    left: 12% !important;
}

.tile img {transition: scale linear 100ms ;}
.tile:hover img {scale:1.1;}
^^;


 
`;

  const db = await openDB_InjectMode();
  const tx = db.transaction(ALT_STORE_NAME, "readwrite");
  const store = tx.objectStore(ALT_STORE_NAME);
  store.put(pluginDump, ALT_KEY_NAME);
})();
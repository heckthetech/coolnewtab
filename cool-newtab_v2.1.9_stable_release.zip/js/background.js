chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'fetchGoogleSuggest') {
    fetch(`https://suggestqueries.google.com/complete/search?client=firefox&q=${encodeURIComponent(request.query)}`)
      .then(res => res.json())
      .then(data => sendResponse({ suggestions: data[1] || [] }))
      .catch(() => sendResponse({ suggestions: [] }));
    return true;
  } else if (request.action === 'fetchYouTubeSuggest') {
    fetch(`https://suggestqueries.google.com/complete/search?client=firefox&q=${encodeURIComponent(request.query)}`)
      .then(res => res.json())
      .then(data => sendResponse({ suggestions: data[1] || [] }))
      .catch(() => sendResponse({ suggestions: [] }));
    return true;
  }
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "open-heckplgn-script" && msg.message) {
    chrome.storage.local.set({
      lastFileContent: msg.message,
      lastFileName: msg.fileName || "unnamed.intheck",
      lastFileLogo: msg.logo || ""
    }, () => {
      chrome.tabs.create({ url: chrome.runtime.getURL("html/plugininstall.html") });
    });
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "get-all-plugins") {
    const req = indexedDB.open("plugindata", 1);
    req.onsuccess = () => {
      const db = req.result;
      const tx = db.transaction("plugins", "readonly");
      const store = tx.objectStore("plugins");
      const getReq = store.get("all");
      getReq.onsuccess = () => {
       if(getReq.result){
        sendResponse({ plugins: getReq.result });}
        else{sendResponse({ plugins: "none"});}
      };
      getReq.onerror = () => {
        sendResponse({ plugins: null });
      };
    };
    req.onerror = () => {
      sendResponse({ plugins: null });
    };
    return true; // async
  }
});

const input = document.getElementById('searchInput');
const suggestions = document.getElementById('suggestions');
const googlemodestyle = document.getElementById("googlemodestyle");
if(!localStorage.searchEngineName){localStorage.setItem('searchEngineName',"Google");}
if(!localStorage.searchEngine){localStorage.setItem('searchEngine',"https://www.google.com/search?q");}
if(!localStorage.searchEngineImage){localStorage.setItem('searchEngineImage',"/assets/google.png");}
input.setAttribute('placeholder',`Search ${localStorage.getItem('searchEngineName')}`);

const DB_NAME = 'autocompleteDB';
const STORE_NAME = 'recents';
const DB_VERSION = 1;
let db;

function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      db = request.result;
      resolve(db);
    };
    request.onupgradeneeded = (e) => {
      db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id', autoIncrement: true });
      }
    };
  });
}

async function saveRecent(entry) {
  if (!entry) return;
  await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.add({ value: entry, timestamp: Date.now() });
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function deleteRecent(value) {
  await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const request = store.openCursor();

    request.onsuccess = function(event) {
      const cursor = event.target.result;
      if (cursor) {
        if (cursor.value.value === value) {
          cursor.delete();
        }
        cursor.continue();
      } else {
        resolve(); // Resolves only after all deletions attempted
      }
    };
    request.onerror = () => reject(request.error);
  });
}

async function getRecent(limit = 100) {
  await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const items = [];
    const request = store.openCursor(null, 'prev');
    request.onsuccess = (e) => {
      const cursor = e.target.result;
      if (cursor && items.length < limit) {
        items.push(cursor.value.value);
        cursor.continue();
      } else {
        resolve(items);
      }
    };
    request.onerror = () => reject(request.error);
  });
}

const specialLinks = ["localhost","data:", "192.168.0.1", "127.0.0.1", "::1"];
let favorites = [];
let favParentDomains = [];

chrome.bookmarks.getTree(function(bookmarkTreeNodes) {
  const urls = [];
  function traverse(nodes) {
    for (const node of nodes) {
      if (node.url) urls.push(node.url);
      if (node.children) traverse(node.children);
    }
  }
  traverse(bookmarkTreeNodes);

  const settings = localStorage.ntabsettings ? JSON.parse(localStorage.ntabsettings) : {};
  favorites = settings.bookmarksuggestions === true ? urls : ["localhost"];

  favParentDomains = favorites
    .map(getParentDomain)
    .filter((v, i, a) => a.indexOf(v) === i);
});

function getParentDomain(url) {
  try {
    const u = new URL(url.startsWith('http') ? url : 'https://' + url);
    return u.hostname.toLowerCase();
  } catch {
    return url.toLowerCase();
  }
}

function normalizeEntry(s) {
  return s.toLowerCase().replace(/^https?:\/\//, '');
}

function isIPAddress(str) {
  const ipv4 = /^(\d{1,3}\.){3}\d{1,3}$/;
  const ipv6 = /^[a-f0-9:]+$/i;
  return ipv4.test(str) || ipv6.test(str);
}

function countFrequency(arr) {
  const freq = {};
  for (const item of arr) {
    const key = normalizeEntry(item);
    freq[key] = (freq[key] || 0) + 1;
  }
  return freq;
}

function sortByFrequency(arr) {
  const freq = countFrequency(arr);
  const unique = [];
  const seen = new Set();
  arr.forEach(item => {
    const norm = normalizeEntry(item);
    if (!seen.has(norm)) {
      seen.add(norm);
      unique.push(item);
    }
  });
  unique.sort((a,b) => freq[normalizeEntry(b)] - freq[normalizeEntry(a)]);
  return unique;
}

let youtubenlLocked = false;

function updateInputModeClasses(val) {
  if (youtubenlLocked) return; // Skip updates if locked in youtubenl-mode

  input.classList.remove('youtube-mode', 'google-mode', 'url-mode');
  const normalized = val.toLowerCase().trim();

  if (normalized.startsWith('youtube.com ')) {
    input.classList.add('youtubenl-mode');
  } else if (normalized === 'youtube.com') {
    input.classList.add('youtube-mode');
  } else if (specialLinks.some(s => normalized.startsWith(s))) {
    input.classList.add('url-mode');
  } else if (
    /^https?:\/\//.test(normalized) ||
    /^[a-z0-9.-]+\.[a-z]{2,}(\/.*)?$/.test(normalized) ||
    isIPAddress(normalized)
  ) {
    input.classList.add('url-mode');
  }else if(!val) {}
   else {
    input.classList.add('google-mode');
  }
}


async function fetchGoogleSuggestions(query) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ action: 'fetchGoogleSuggest', query }, response => {
      resolve(response?.suggestions || []);
    });
  });
}

async function fetchYoutubeSuggestions(query) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ action: 'fetchYoutubeSuggest', query }, response => {
      resolve(response?.suggestions || []);
    });
  });
}

let lastValue = "";
let selectedIndex = -1;
let wikiSuggestions = [];
let recentSuggestions = [];
let youtubeSuggestions = [];

input.addEventListener("input", async () => {
  selectedIndex = -1;
  const val = input.value;
  updateInputModeClasses(val);
  const valLower = val.toLowerCase();

  if (valLower.length === 0) {
    suggestions.innerHTML = '';
    lastValue = "";
    youtubeSuggestions = [];
    input.classList.remove('youtube-mode', 'google-mode', 'url-mode', 'special-mode');
    return;
  }

  if (valLower === 'y' && lastValue.length < valLower.length) {
    input.value = 'youtube.com';
    input.setSelectionRange(1, input.value.length);
    lastValue = 'youtube.com';
    youtubeSuggestions = [];
    renderSuggestions([]);
    updateInputModeClasses(input.value); // fix mode
    return;
  }

  const isTypingForward = valLower.length > lastValue.length;
  lastValue = valLower;

  if (input.classList.contains('youtube-mode')) {
    const query = valLower.replace(/^youtube\.com\s*/, '');
    const ytApiSuggestions = await fetchYoutubeSuggestions(query);
    const recentsRaw = await getRecent(200);
    const ytRecents = recentsRaw
      .filter(item => item.startsWith('youtube.com/results?search_query='))
      .map(item => {
        try {
          const url = new URL('https://' + item);
          return decodeURIComponent(url.searchParams.get('search_query') || '');
        } catch {
          return '';
        }
      })
      .filter(q => q && q.startsWith(query));
    const merged = [...new Set([...ytRecents, ...ytApiSuggestions])];
    youtubeSuggestions = merged;
    renderSuggestions([]);
    return;
  }

  const recentsRaw = await getRecent(200);
  const filteredRecents = recentsRaw.filter(item => !item.startsWith('youtube.com/results?search_query='));
  const sortedRecents = sortByFrequency(filteredRecents);
  recentSuggestions = sortedRecents.filter(item => normalizeEntry(item).startsWith(valLower));

  const specialFiltered = specialLinks.filter(s => s.startsWith(valLower));
  specialFiltered.forEach(s => {
    if (!recentSuggestions.some(r => normalizeEntry(r) === normalizeEntry(s))) {
      recentSuggestions.push(s);
    }
  });

  const favSuggestions = favParentDomains.filter(domain => domain.startsWith(valLower));

  try {
    const data = await fetchGoogleSuggestions(valLower);
    wikiSuggestions = data.filter(title =>
      !recentSuggestions.some(r => normalizeEntry(r) === normalizeEntry(title)) &&
      !favSuggestions.some(f => normalizeEntry(f) === normalizeEntry(title))
    );
  } catch {
    wikiSuggestions = [];
  }

  if (isTypingForward && valLower.length > 0) {
    const recMatch = recentSuggestions.find(item => normalizeEntry(item).startsWith(valLower));
    if (recMatch) {
      const displayMatch = recMatch.replace(/^https?:\/\//, '');
      input.value = displayMatch;
      input.setSelectionRange(valLower.length, displayMatch.length);
      updateInputModeClasses(displayMatch);
    } else {
      const favMatch = favSuggestions.find(fav => fav.startsWith(valLower));
      if (favMatch) {
        input.value = favMatch;
        input.setSelectionRange(valLower.length, favMatch.length);
        updateInputModeClasses(favMatch);
      }
    }
  }

  renderSuggestions(favSuggestions);
});

function renderSuggestions(favSuggestions) {
  if (input.classList.contains('youtube-mode')) {
    if (youtubeSuggestions.length === 0) {
      suggestions.innerHTML = '';
      return;
    }
    const ytHTML = youtubeSuggestions.map((title,i) => `<li${i===selectedIndex?' class=" active"':''} class="recentyt" data-full="${title}">${title}</li>`).join('');
    suggestions.innerHTML = ytHTML;
    return;
  }

  if (recentSuggestions.length === 0 && favSuggestions.length === 0 && wikiSuggestions.length === 0) {
    suggestions.innerHTML = '';
    return;
  }

  const recentHTML = recentSuggestions.map((item,i) => `<li class="recent${i===selectedIndex?' active':''}" data-full="${item}">${item.replace(/^https?:\/\//,'')}</li>`).join('');
  const favHTML = favSuggestions.map((domain,i) => `<li class="fav${i+recentSuggestions.length===selectedIndex?' active':''}" data-full="${domain}">${domain}</li>`).join('');
  const wikiHTML = wikiSuggestions.map((title,i) => `<li${i+recentSuggestions.length+favSuggestions.length===selectedIndex?' class="active"':''} data-full="${title}">${title}</li>`).join('');

  suggestions.innerHTML = recentHTML + favHTML + wikiHTML;
}

suggestions.addEventListener('click', async e => {
  if (e.target.tagName==='LI') await handleNavigation(e.target.getAttribute('data-full'));
});

suggestions.addEventListener('contextmenu', async e => {
  if (e.target.tagName === 'LI') {
    e.preventDefault();
    const val = e.target.getAttribute('data-full');
    const isYoutubeRecent = input.classList.contains('youtube-mode');
    if (isYoutubeRecent || e.target.classList.contains('recent')) {
      if (confirm('Delete this?')) {
        if (isYoutubeRecent) {
          const fullVal = `youtube.com/results?search_query=${encodeURIComponent(val)}`;
          await deleteRecent(fullVal);
          youtubeSuggestions = youtubeSuggestions.filter(item => item !== val);
        } else {
          await deleteRecent(val);
          recentSuggestions = recentSuggestions.filter(item => item !== val);
        }
        renderSuggestions(favParentDomains.filter(domain => domain.startsWith(input.value.toLowerCase())));
      }
    }
  }
});

input.addEventListener('keydown', async e => {
  const items = suggestions.querySelectorAll('li');
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    if (!items.length) return;
    e.preventDefault();
    selectedIndex = e.key === 'ArrowDown' ? (selectedIndex + 1) % items.length : (selectedIndex - 1 + items.length) % items.length;
    updateActive();
  } else if (e.key === 'Tab') {
  if (input.value.toLowerCase().startsWith('youtube.com')) {
    youtubenlLocked = true;
    e.preventDefault();
    input.classList.remove('youtube-mode');
    input.classList.add('youtubenl-mode');
    input.setAttribute('placeholder','Search Youtube');
    input.value = ''; // clear value
    lastValue = '';
    selectedIndex = -1;
    input.dispatchEvent(new Event('input'));
  }  } else if (e.key === 'Enter') {
    e.preventDefault();
    if (selectedIndex >= 0 && items.length) await handleNavigation(items[selectedIndex].getAttribute('data-full'));
    else await handleNavigation(input.value.trim().toLowerCase());
    suggestions.innerHTML = '';
    selectedIndex = -1;
  } 
else if (e.key === 'Backspace') {
  if (youtubenlLocked && input.value.trim() === '') {
    youtubenlLocked = false;
    input.classList.remove('youtubenl-mode');
       input.setAttribute('placeholder',`Search ${localStorage.getItem('searchEngineName')}`);
    updateInputModeClasses('');
  }
}

});

document.getElementById('searchbtnn').onclick = async function() {
  const items = suggestions.querySelectorAll('li');
  if (selectedIndex >= 0 && items.length) {
    await handleNavigation(items[selectedIndex].getAttribute('data-full'));
  } else {
    await handleNavigation(input.value.trim().toLowerCase());
  }
  suggestions.innerHTML = '';
  selectedIndex = -1;
};

function updateActive() {
  const items = suggestions.querySelectorAll('li');
  items.forEach((item,i) => item.classList.toggle('active', i === selectedIndex));
  if (selectedIndex >= 0 && items[selectedIndex]) {
    const full = items[selectedIndex].getAttribute('data-full');
    input.value = full.replace(/^https?:\/\//, '');
    items[selectedIndex].scrollIntoView({ block: 'nearest' });
  }
}

async function handleNavigation(val) {
  let fullText = val.trim();
  const norm = normalizeEntry(fullText);

  const isFullURL = /^https?:\/\/[^\s]+$/i.test(fullText);
  const domainWithPath = /^[a-z0-9.-]+\.[a-z]{2,}([\/?#].*)?$/i.test(norm);
  const special = specialLinks.some(s => norm.startsWith(s));
  const ip = isIPAddress(norm);
  const isOnlyDigits = /^\d+$/.test(norm);
  const containsDot = norm.includes('.');
  const isGibberish = /^[a-z]{5,}$/i.test(norm); // e.g. aaaaaa

if (input.classList.contains('youtubenl-mode')) {
  const query = fullText.trim();
  if (!query) {
    window.location.replace('https://www.youtube.com/');
    return;
  }
  await saveRecent(`youtube.com/results?search_query=${encodeURIComponent(query)}`);
  window.location.replace(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`);
  return;
}

if (input.classList.contains('youtube-mode')) {
  window.location.replace('https://www.youtube.com/');
  return;
}


function openDataURLInNewTab(dataURL) {
  // Extract media type from data URL: data:[<mediatype>][;base64],<data>
  const match = dataURL.match(/^data:([^;,]+)(;base64)?,/i);
  const mediaType = match ? match[1].toLowerCase() : '';

  // Basic categorization
  const isImage = mediaType.startsWith('image/');
  const isVideo = mediaType.startsWith('video/');
  const isAudio = mediaType.startsWith('audio/');
  const isText = mediaType.startsWith('text/') || mediaType === 'application/json' || mediaType === 'application/xml';

  // Build HTML depending on type
  let content = '';
  if (isImage) {
    content = `<img src="${dataURL}" style="display:block; max-width:100vw; max-height:100vh; margin:auto; background:#eee;" alt="Data URL Image">`;
  } else if (isVideo) {
    content = `<video controls autoplay style="display:block; max-width:100vw; max-height:100vh; margin:auto; background:#000;">
      <source src="${dataURL}" type="${mediaType}">
      Your browser does not support the video tag.
    </video>`;
  } else if (isAudio) {
    content = `<audio controls autoplay style="display:block; width: 100%; margin:auto;">
      <source src="${dataURL}" type="${mediaType}">
      Your browser does not support the audio element.
    </audio>`;
  } else if (isText) {
    // Display text in iframe with monospace font
    content = `<iframe srcdoc="<pre style='white-space: pre-wrap; font-family: monospace;'>${escapeHtml(atob(dataURL.split(',')[1]))}</pre>" style="width:100vw; height:100vh; border:none;"></iframe>`;
  } else {
    // Fallback: embed in iframe (for unknown types)
    content = `<iframe src="${dataURL}" style="width:100vw; height:100vh; border:none;"></iframe>`;
  }

  // Full HTML template
  const html = `
<!DOCTYPE html>
<html lang="en" style="height:100%; margin:0;">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Data URL Viewer</title>
<style>
  body, html { height: 100%; margin: 0; display: flex; align-items: center; justify-content: center; background: #111; color: #eee; }
</style>
</head>
<body>${content}</body>
</html>`;

  // Open new tab and write HTML
  const newTab = window.open();
  if (!newTab) {
    alert('Pop-up blocked! Please allow pop-ups for this site.');
    return;
  }
  newTab.document.write(html);
  newTab.document.close();

  // Helper to escape HTML for text display
  function escapeHtml(text) {
    return text.replace(/[&<>"']/g, c => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    })[c]);
  }
}




  if (isFullURL) {
  //keep it as is
} else if (favParentDomains.includes(norm)) {
  fullText = `https://${norm}`;
} else if ((domainWithPath || special || ip || containsDot) && !isOnlyDigits && !isGibberish) {
  if (norm.startsWith('http') || norm.startsWith('data:')) {
    fullText = norm;
  } else if (special || ip) {
    fullText = `http://${norm}`;
  } else {
    fullText = `https://${norm}`;
  }
} else {
  await saveRecent(norm);
  window.location.replace(`${localStorage.getItem('searchEngine')}=${encodeURIComponent(norm)}`);
  return;
}

// ✅ Handle data: safely
await saveRecent(fullText);
if (fullText.startsWith('data:')) {
openDataURLInNewTab(input.value);
} else {
  window.location.replace(fullText);
}}

googlemodestyle.innerHTML = `
 .google-mode{
    background-image: url("${localStorage.getItem('searchEngineImage')}");
    background-size: 30px 30px;
    background-repeat: no-repeat;
    background-position-x: 3px;
    background-position-y: 8px;
    padding: 14px 50px 14px 40px !important;
    color: #ffffff !important;}
`;
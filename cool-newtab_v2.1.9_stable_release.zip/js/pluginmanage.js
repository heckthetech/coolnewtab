let plugins = [], exportMode = false, currentIndex = null;
const DELIM = "////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////";
const pContainer = document.getElementById("plugins");
const modal = document.getElementById("editorModal");
const editor = document.getElementById("modalEditor");
const titleBar = modal.querySelector(".title");
const fileInput = document.getElementById("fileInput");
const explore = document.getElementById("exploreCommunity");
const manual = document.getElementById("languagemanual");

explore.onclick = () => {window.location.replace("http://heckthetech.github.io/coolnewtab/pluginstore")}
manual.onclick = () => {window.open("./manual.html")}

function generateTimestamp() {
  const now = new Date();
  const day = now.toLocaleDateString(undefined, { weekday: 'long' });
  return (
    now.getFullYear().toString() +
    (now.getMonth() + 1).toString().padStart(2, '0') +
    now.getDate().toString().padStart(2, '0') +
    now.getHours().toString().padStart(2, '0') +
    now.getMinutes().toString().padStart(2, '0') +
    now.getSeconds().toString().padStart(2, '0') +
    day
  );
}

const DB_NAME = "plugindata";
const STORE_NAME = "plugins";
const KEY_NAME = "all";

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => resolve(req.result);
    req.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
  });
}

async function getPluginsFromDB() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const req = store.get(KEY_NAME);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function savePluginsToDB(data) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const req = store.put(data, KEY_NAME);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// Updated load function
async function load() {
  try {
    const saved = await getPluginsFromDB();
    plugins = saved ? saved.split(DELIM) : [];
    render();
  } catch (e) {
    console.error("Failed to load plugins from IndexedDB:", e);
    plugins = [];
    render();
  }
}

// Updated saveAll function
async function saveAll() {
  try {
    await savePluginsToDB(plugins.join(DELIM));
    localStorage.latest = generateTimestamp(); // keep timestamp in localStorage for now
  } catch (e) {
    console.error("Failed to save plugins to IndexedDB:", e);
  }
}

// Replace window.onload to async call
window.onload = () => {
  load();
};
function parseMeta(code) {
  const line = code.split("\n")[0] || "";
  const rx = /\/\/\s*pluginname\{([^}]*)\}\s*version\{([^}]*)\}\s*Author\{([^}]*)\}/i;
  const m = line.match(rx);
  return m ? { name: m[1], version: m[2], author: m[3] } : {};
}
function render() {
  pContainer.innerHTML = "";
  pContainer.classList.toggle("export-mode", exportMode);
  plugins.forEach((code, idx) => {
    const meta = parseMeta(code);
    const card = document.createElement("div");
    card.className = "plugin-card";
    card.innerHTML = `
      <h3>${meta.name || "Plugin #" + (idx + 1)}</h3>
      <div class="plugin-meta">
        ${meta.version ? `version : ${meta.version}` : ""}<br>Created By : 
        ${meta.author || ""}
      </div>
      <button class="edit-btn">Edit in Console</button>
      <button class="delete-btn">Delete Plugin</button>
      <button class="export-btn">Export</button>
    `;
    card.querySelector(".edit-btn").onclick = () => openEditor(idx);
    card.querySelector(".delete-btn").onclick = () => { plugins.splice(idx, 1); saveAll(); render(); };
    card.querySelector(".export-btn").onclick = () => downloadPlugin(idx);
    pContainer.appendChild(card);
    localStorage.latest = generateTimestamp();
  });
}
function openEditor(idx) {
  currentIndex = idx;
  editor.value = plugins[idx];
  const meta = parseMeta(editor.value);
  titleBar.textContent = meta.name
    ? `${meta.name}`
    : `Editing Plugin #${idx + 1}`;
  modal.style.display = "flex";
  editor.focus();
  updateHighlight();
}
function downloadPlugin(idx) {
  const code = plugins[idx];
  const meta = parseMeta(code);
  const name = (meta.name || `plugin${idx + 1}`) + ".intheck";
  const blob = new Blob([code], { type: "text/plain" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  URL.revokeObjectURL(a.href);
}

document.getElementById("importPlugin").onclick = () => fileInput.click();
fileInput.onchange = e => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const importedCode = reader.result;
    const importedMeta = parseMeta(importedCode);
    if (!importedMeta.name || !importedMeta.author || !importedMeta.version) {
      plugins.push(importedCode); saveAll(); render(); return;
    }
    const existingIndex = plugins.findIndex(p => {
      const m = parseMeta(p);
      return m.name === importedMeta.name && m.author === importedMeta.author;
    });
    if (existingIndex === -1) {
      plugins.push(importedCode); saveAll(); render(); return;
    }
    const existingMeta = parseMeta(plugins[existingIndex]);
    function isNewerVersion(v1, v2) {
      const toNums = v => v.split(".").map(x => parseInt(x) || 0);
      const a = toNums(v1), b = toNums(v2);
      for (let i = 0; i < Math.max(a.length, b.length); i++) {
        if ((a[i] || 0) > (b[i] || 0)) return true;
        if ((a[i] || 0) < (b[i] || 0)) return false;
      }
      return false;
    }
    if (importedMeta.version === existingMeta.version) {
      alert(`Plugin "${importedMeta.name}" by ${importedMeta.author} version ${importedMeta.version} already exists.`);
      return;
    }
    if (isNewerVersion(importedMeta.version, existingMeta.version)) {
      plugins[existingIndex] = importedCode;
      saveAll();
      render();
      alert(`Plugin "${importedMeta.name}" by ${importedMeta.author} updated to version ${importedMeta.version}.`);
      return;
    }
    alert(`A newer or same version of plugin "${importedMeta.name}" by ${importedMeta.author} already exists.`);
  };
  reader.readAsText(file);
  fileInput.value = "";
  
};
document.getElementById("exportMode").onclick = () => {
  exportMode = !exportMode;
  render();
};
document.getElementById("saveBtn").onclick = () => {
  plugins[currentIndex] = editor.value;
  saveAll();
  render();
  modal.style.display = "none";
};
document.getElementById("cancelBtn").onclick = () => {
  modal.style.display = "none";
};

window.onload = load;

const highlight = document.getElementById('highlight');
const suggestions = document.getElementById('suggestions');
const keywords = [
  "set", "default", "create", "div", "with", "id", "eventlistener-on",
  "doing", "localstorage", "inc", "dec", "reset", "loadtextfrom",
  "getvalue", "dragmovable", "stored", "searcher", "for", "inputid",
  "buttonid", "override", "css"
];

const lang = [`create div with id(#id) ^^
^^;`,`set override css = ^^
  id {}
^^;`,`create eventlistener-on(#id)-doing^^
  ~~task~~
^^;`];

const cssProps = [ "align-content", "align-items", "align-self", "all", "animation", "animation-delay", "animation-direction","animation-duration", "animation-fill-mode", "animation-iteration-count", "animation-name", "animation-play-state","animation-timing-function", "backface-visibility", "background", "background-attachment", "background-blend-mode","background-clip", "background-color", "background-image", "background-origin", "background-position","background-repeat", "background-size", "border", "border-bottom", "border-bottom-color", "border-bottom-left-radius","border-bottom-right-radius", "border-bottom-style", "border-bottom-width", "border-collapse", "border-color","border-image", "border-image-outset", "border-image-repeat", "border-image-slice", "border-image-source","border-image-width", "border-left", "border-left-color", "border-left-style", "border-left-width", "border-radius","border-right", "border-right-color", "border-right-style", "border-right-width", "border-spacing", "border-style","border-top", "border-top-color", "border-top-left-radius", "border-top-right-radius", "border-top-style","border-top-width", "border-width", "bottom", "box-decoration-break", "box-shadow", "box-sizing", "break-after","break-before", "break-inside", "caption-side", "caret-color", "clear", "clip", "color", "column-count", "column-fill","column-gap", "column-rule", "column-rule-color", "column-rule-style", "column-rule-width", "column-span","column-width", "columns", "content", "counter-increment", "counter-reset", "cursor", "direction", "display","empty-cells", "filter", "flex", "flex-basis", "flex-direction", "flex-flow", "flex-grow", "flex-shrink", "flex-wrap","float", "font", "font-family", "font-feature-settings", "font-kerning", "font-language-override", "font-size","font-size-adjust", "font-stretch", "font-style", "font-synthesis", "font-variant", "font-variant-caps","font-variant-east-asian", "font-variant-ligatures", "font-variant-numeric", "font-weight", "gap", "grid","grid-area", "grid-auto-columns", "grid-auto-flow", "grid-auto-rows", "grid-column", "grid-column-end","grid-column-gap", "grid-column-start", "grid-gap", "grid-row", "grid-row-end", "grid-row-gap", "grid-row-start","grid-template", "grid-template-areas", "grid-template-columns", "grid-template-rows", "hanging-punctuation", "height","hyphens", "image-rendering", "inline-size", "isolation", "justify-content", "left", "letter-spacing", "line-break","line-height", "list-style", "list-style-image", "list-style-position", "list-style-type", "margin", "margin-bottom","margin-left", "margin-right", "margin-top", "max-block-size", "max-height", "max-inline-size", "max-width", "min-block-size","min-height", "min-inline-size", "min-width", "mix-blend-mode", "object-fit", "object-position", "opacity", "order","orphans", "outline", "outline-color", "outline-offset", "outline-style", "outline-width", "overflow", "overflow-wrap","overflow-x", "overflow-y", "padding", "padding-bottom", "padding-left", "padding-right", "padding-top", "page-break-after","page-break-before", "page-break-inside", "perspective", "perspective-origin", "place-content", "place-items","place-self", "pointer-events", "position", "quotes", "resize", "right", "scroll-behavior", "scroll-margin","scroll-margin-block", "scroll-margin-block-start", "scroll-margin-block-end", "scroll-margin-inline","scroll-margin-inline-start", "scroll-margin-inline-end", "scroll-padding", "scroll-padding-block","scroll-padding-block-start", "scroll-padding-block-end", "scroll-padding-inline", "scroll-padding-inline-start","scroll-padding-inline-end", "scroll-snap-align", "scroll-snap-stop", "scroll-snap-type", "tab-size", "table-layout","text-align", "text-align-last", "text-combine-upright", "text-decoration", "text-decoration-color", "text-decoration-line","text-decoration-style", "text-indent", "text-justify", "text-orientation", "text-overflow", "text-shadow","text-transform", "text-underline-position", "top", "transform", "transform-box", "transform-origin", "transform-style","transition", "transition-delay", "transition-duration", "transition-property", "transition-timing-function","unicode-bidi", "user-select", "vertical-align", "visibility", "white-space", "widows", "width", "word-break", "word-spacing","word-wrap", "writing-mode", "z-index" ];

function escapeHtml(text) {
  return text.replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m]);
}

function highlightGlobalFuncs(code) {
  ["loadtextfrom", "getvalue", "set", "create", "inc", "dec", "reset"].forEach(fn => {
    code = code.replace(new RegExp(`\\b${fn}\\b`, 'g'), `<span class="function">${fn}</span>`);
  });
  return code;
}
function syntaxHighlight(code) {
  code = escapeHtml(code);

  code = code.replace(/\/\/.*/g, m => `<span class="comment">${m}</span>`);

  code = code.replace(/\b\d+(\.\d+)?\b/g, m => `<span class="number">${m}</span>`);

  code = code.replace(/(?<!["'])\.[a-zA-Z0-9_-]+\b/g, m => `<span class="selector">${m}</span>`);
  code = code.replace(/(?<!["'])#[a-zA-Z0-9_-]+\b/g, m => `<span class="selector">${m}</span>`);

  keywords.forEach(kw => {
    code = code.replace(new RegExp(`\\b${kw}\\b`, 'g'), `<span class="keyword">${kw}</span>`);
  });

  cssProps.forEach(prop => {
    code = code.replace(new RegExp(`\\b${prop}\\b`, 'g'), `<span class="cssprop">${prop}</span>`);
  });

  code = highlightGlobalFuncs(code);

  if (code.endsWith('\n')) code += '&#8203;';

  return code;
}

let lastSuggestionStart = null, lastSuggestionEnd = null;
function updateHighlight() {
  const val = editor.value;
  highlight.innerHTML = syntaxHighlight(val);
  const cursorPos = editor.selectionStart;
  const textBefore = val.slice(0, cursorPos);
  const match = textBefore.match(/(\b\w+)$/);
  if (match) {
    const word = match[1].toLowerCase();
    const start = cursorPos - word.length;
    const end = cursorPos;

    const combinedList = [ ...lang, ...keywords, ...cssProps  ];
    const matches = combinedList.filter(k => k.startsWith(word));

    if (matches.length) {
      lastSuggestionStart = start;
      lastSuggestionEnd = end;
      showSuggestions(matches);
      return;
    }
  }
  hideSuggestions();
}

function showSuggestions(list) {
  suggestions.innerHTML = "";
  list.forEach((item, i) => {
    const div = document.createElement('div');
    div.textContent = item;
    if (i === 0) div.classList.add('selected');
    div.addEventListener('mousedown', e => {
      e.preventDefault();
      insertSuggestion(item);
    });
    suggestions.appendChild(div);
  });
  suggestions.style.display = 'block';
}

function hideSuggestions() {
  suggestions.style.display = 'none';
  lastSuggestionStart = null;
  lastSuggestionEnd = null;
}

function insertSuggestion(text) {
  const val = editor.value;
  if (lastSuggestionStart !== null && lastSuggestionEnd !== null) {
    editor.value = val.slice(0, lastSuggestionStart) + text + val.slice(lastSuggestionEnd);
    const newPos = lastSuggestionStart + text.length;
    editor.selectionStart = editor.selectionEnd = newPos;
    editor.focus();
    updateHighlight();
  }
  hideSuggestions();
}

editor.addEventListener('input', updateHighlight);
editor.addEventListener('scroll', () => {
  highlight.scrollTop = editor.scrollTop;
  highlight.scrollLeft = editor.scrollLeft;
});

editor.addEventListener('keydown', e => {
  if (suggestions.style.display === 'block') {
    const selected = suggestions.querySelector('.selected');
    if (!selected) return;
    let newSelected;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      newSelected = selected.nextSibling || suggestions.firstChild;
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      newSelected = selected.previousSibling || suggestions.lastChild;
    } else if (e.key === "Enter" || e.key === "Tab") {
      e.preventDefault();
      insertSuggestion(selected.textContent);
    }
    if (newSelected) {
      selected.classList.remove('selected');
      newSelected.classList.add('selected');
    }
  }
});

const createPopup = document.getElementById("createPopup");
const basicCreateBtn = document.getElementById("basicCreateBtn");
const codeCreateBtn = document.getElementById("codeCreateBtn");
const createCancelBtn = document.getElementById("createCancelBtn");

document.getElementById("addPlugin").onclick = () => {
  createPopup.style.display = "block";
};
codeCreateBtn.onclick = () => {
  createPopup.style.display = "none";
  plugins.push("//pluginname{NewPlugin}version{1.0}Author{You}\n");
  saveAll();
  render();
  openEditor(plugins.length - 1);
};

createCancelBtn.onclick = () => {
  createPopup.style.display = "none";
};

const basicCreateModal = document.getElementById("basicCreateModal");
const createStickerBtn = document.getElementById("createStickerBtn");
const stickerForm = document.getElementById("stickerForm");
const stickerNameInput = document.getElementById("stickerName");
const stickerAuthorInput = document.getElementById("stickerAuthor");
const stickerImageInput = document.getElementById("stickerImage");
const stickerCancelBtn = document.getElementById("stickerCancelBtn");

basicCreateBtn.onclick = () => {
  createPopup.style.display = "none";
  basicCreateModal.style.display = "flex";
  document.getElementById("basicOptions").style.display = "flex";
  stickerForm.style.display = "none";
  stickerForm.reset();
};

createStickerBtn.onclick = () => {
  document.getElementById("basicOptions").style.display = "none";
  stickerForm.style.display = "flex";
};

stickerCancelBtn.onclick = () => {
  basicCreateModal.style.display = "none";
};

stickerForm.onsubmit = async e => {
  e.preventDefault();

  const name = stickerNameInput.value.trim();
  const author = stickerAuthorInput.value.trim();
  const height = document.getElementById("stickerHeight").value.trim();
  const file = stickerImageInput.files[0];
  if (!name || !author || !file || !height) {
    alert("Please fill all fields and select an image.");
    return;
  }

  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject("Failed to read file");
    reader.readAsDataURL(file);
  });

  const pluginCode = `//pluginname{${name}}version{1.0}Author{${author}}

set override css = ^^
#${name}{z-index: 90;}
^^;

default localstorage.drag_${name} = 15,15; 

create div with id(#${name}) ^^
<img style="border-radius: 5px; height: ${height}px;" dragmovable="stored" src="${dataUrl}">
^^;`;

  plugins.push(pluginCode);
  saveAll();
  render();
  basicCreateModal.style.display = "none";
};

const createTextNoteBtn = document.getElementById("createTextNoteBtn");
const textNoteForm = document.getElementById("textNoteForm");
const textNoteCancelBtn = document.getElementById("textNoteCancelBtn");

createTextNoteBtn.onclick = () => {
  document.getElementById("basicOptions").style.display = "none";
  document.getElementById("stickerForm").style.display = "none";
  textNoteForm.style.display = "flex";
  textNoteForm.reset();
};

textNoteCancelBtn.onclick = () => {
  basicCreateModal.style.display = "none";
  textNoteForm.style.display = "none";
};

textNoteForm.onsubmit = e => {
  e.preventDefault();

  const name = document.getElementById("textNoteName").value.trim();
  const author = document.getElementById("textNoteAuthor").value.trim();

  if (!name || !author) {
    alert("Please fill all fields.");
    return;
  }

  const plugin = `//pluginname{${name}}version{1.0}Author{${author}} 

set override css = ^^
  #${name} { z-index: 1; width: auto; height: auto; } 
  #${name}1 { 
    width: auto;
    height: auto;
    font-family: "Pfont";
    cursor: grab;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 500px;
    max-height: 400px;
    font-size: 30px;
    border: none;
  }
  #${name}1:focus {
    border: 2px solid #eb7070;
    border-radius: 5px;
    outline: none;
  }
^^;

create div with id(#${name})^^ 
<div id="${name}1" edit="stored" dragmovable="0,0,stored">edit me</div> 
^^;`;

  plugins.push(plugin);
  saveAll();
  render();
  basicCreateModal.style.display = "none";
  textNoteForm.style.display = "none";
};

window.onload = async () => {
  const scriptLoadedEl = document.getElementById("scriptloaded");
  const output = document.getElementById("output");

  function openDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open("plugindata", 1);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(req.result);
      req.onupgradeneeded = e => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains("plugins")) {
          db.createObjectStore("plugins");
        }
      };
    });
  }

  function getPlugins(db) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction("plugins", "readonly");
      const store = tx.objectStore("plugins");
      const getReq = store.get("all");
      getReq.onsuccess = () => resolve(getReq.result);
      getReq.onerror = () => reject(getReq.error);
    });
  }

  async function loadAndInterpretPlugins() {
    try {
      const db = await openDB();
      const saved = await getPlugins(db);
      if (!saved) {
        scriptLoadedEl.innerHTML = "none";
        console.log(
          "%cNo Plugins Installed",
          "color:rgb(162, 193, 255); font-size: 16px; font-family: Calibri; font-weight: bold; background: #1e1e1e; padding: 6px 10px; border-left: 4px solid rgb(17, 0, 255);"
        );
        return;
      }

      const DELIM = "////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////";
      const blocks = saved.split(DELIM);

      output.innerHTML = "";

      blocks.forEach((code, index) => {
        try {
          interpret(code, false); // interpret plugin-wise
        } catch (err) {
          console.error(`Script #${index + 1} failed:\n`, err);
        }
      });

      window.lastScript = blocks.join("\n/////\n");
      scriptLoadedEl.innerHTML = "done";
    } catch (e) {
      console.error("Failed to load plugins from IndexedDB:", e);
      scriptLoadedEl.innerHTML = "error";
    }
  }

  // Initial load
  await loadAndInterpretPlugins();

  // Interval to check and re-run interpreter if needed
  const DB_NAME = "plugindata";
  const STORE_NAME = "plugins";
  const KEY_NAME = "all";
  const db = await openDB();

  setInterval(async () => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);

    const data = await new Promise((res) => {
      const req = store.get(KEY_NAME);
      req.onsuccess = () => res(req.result);
      req.onerror = () => res(null);
    });

    if (!data) return; // no data, do nothing

    const el = document.getElementById("scriptloaded");
    if (el && el.innerHTML.trim() === "none") {
      // Instead of reload, re-run interpreter
      await loadAndInterpretPlugins();
    }
  }, 100);
};
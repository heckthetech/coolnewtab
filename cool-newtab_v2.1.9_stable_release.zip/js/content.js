window.addEventListener("load", () => {
const manifest = chrome.runtime.getManifest();
const name = manifest.name;
const version = manifest.version;
const versionnote = manifest.versionnote || "";
const el = document.getElementById("checkextensioninstalled");
  if (el) {
    el.innerHTML = `Installed | ${name} <br> version <b id="versionnumber">${version}</b> | <b>${versionnote}</b>`;
    el.setAttribute('data','installed');
  } 
});


window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  const msg = event.data;

  if (msg?.type === "send-int-plugin-to-install-heck" && msg.base64Data) {
    chrome.runtime.sendMessage({
      action: "open-heckplgn-script",
      message: msg.base64Data,
      fileName: msg.fileName,
      logo: msg.logo
    });
  }
  
 if (event.data === "requestPluginData") {
    console.log("→ content.js received requestPluginData");
    chrome.runtime.sendMessage({ action: "get-all-plugins" }, res => {
      console.log("← content.js got response:", res);
      if (res?.plugins) {
        window.postMessage({ type: "injectPluginData", data: res.plugins }, "*");
      }
    });
  }
});


const clockToggle = document.getElementById('clockFormatToggle');
const wallpaperToggle = document.getElementById('wallpaperToggle');
const bookmarksuggestionsToggle = document.getElementById('bookmarksuggestionsToggle');
const wall = document.getElementById('wall');
const backtomainpopupbtn = document.getElementById('backtomainpopupbtn');
const pluginsettingsbtn = document.getElementById('pluginSettingsBtn');
const managepluginbtn = document.getElementById('managepluginBtn');
const selectedText = document.getElementById('selectedText');
const selectedSearch = document.getElementById('selectedSearch');
const currentIcon = selectedSearch.querySelector('img');
const searchOptions = document.getElementById('searchOptions');

if(!localStorage.searchEngineName){localStorage.setItem('searchEngineName',"Google");}
if(!localStorage.searchEngine){localStorage.setItem('searchEngine',"https://www.google.com/search?q");}
if(!localStorage.searchEngineImage){localStorage.setItem('searchEngineImage',"/assets/google.png");}

setInterval(() => {
  if (selectedText.textContent !== localStorage.searchEngineName) {
  window.location.reload();;
}
}, 100);

 managepluginbtn.onclick = () => {window.open('./plugin.html');};
 pluginSettingsBtn.onclick = () => {
      document.getElementById("mainPopup").style.display = "none";
      document.getElementById("pluginPopup").style.display = "flex";
    };
backtomainpopupbtn.onclick = () => {
      document.getElementById("mainPopup").style.display = "flex";
      document.getElementById("pluginPopup").style.display = "none";
    };

 (function () {
  try {
    const settings = JSON.parse(localStorage.getItem('ntabsettings'));
    if (
      settings &&
      typeof settings === 'object' &&
      ('newtabclockform' in settings) &&
      ('wallpaperEnabled' in settings)&&
      ('bookmarksuggestions' in settings)
    ) {
      return; // Already valid, do nothing
    }
  } catch {}

  // Create default if missing or corrupted
  const defaultSettings = {
    newtabclockform: '12',
    wallpaperEnabled: true,
    bookmarksuggestions: true

  };
  localStorage.setItem('ntabsettings', JSON.stringify(defaultSettings));
})();


function loadSettings() {
  const storedSearch = localStorage.getItem('searchEngine');
if (storedSearch) {
    selectedText.textContent = localStorage.getItem('searchEngineName') ;
    currentIcon.src = localStorage.getItem('searchEngineImage');
}

    try {
      const settings = JSON.parse(localStorage.getItem('ntabsettings')) || {};
      const clockFormat = settings.newtabclockform === '24' ? '24' : '12';
      const wallpaperEnabled = settings.wallpaperEnabled === true;
      const bookmarksuggestionsenabled = settings.bookmarksuggestions === true;

      clockToggle.checked = clockFormat === '24';
      wallpaperToggle.checked = wallpaperEnabled;
      bookmarksuggestionsToggle.checked = bookmarksuggestionsenabled;
    } catch {
      // Default fallback
      clockToggle.checked = false; // 12h by default
      wallpaperToggle.checked = true; // wallpaper on by default
     bookmarksuggestionsToggle.checked = true; // bookmarksuggestions on by default
    }
  }


loadSettings();
function generateTimestamp() {
  const now = new Date();
  const day = now.toLocaleDateString(undefined, { weekday: 'long' });
  return (
    now.getFullYear().toString() +
    (now.getMonth() + 1).toString().padStart(2, '0') +
    now.getDate().toString().padStart(2, '0') +
    now.getHours().toString().padStart(2, '0') +
    now.getMinutes().toString().padStart(2, '0') +
    now.getSeconds().toString().padStart(2, '0') +
    day
  );
}


selectedSearch.addEventListener('click', () => {
  searchOptions.style.display = (searchOptions.style.display === 'flex') ? 'none' : 'flex';
});

searchOptions.querySelectorAll('.search-option').forEach(option => {
  option.addEventListener('click', () => {
    const { url, name, icon } = option.dataset;

    selectedText.textContent = name;
    currentIcon.src = icon;

    localStorage.setItem('searchEngine', url);
    localStorage.setItem('searchEngineImage', `/assets/${name.toLowerCase()}.png`);
    localStorage.setItem('searchEngineName', name);
    localStorage.latest = generateTimestamp();
    searchOptions.style.display = 'none';
  });
});


// Click outside to close dropdown
document.addEventListener('click', e => {
  if (!document.getElementById('customSearchDropdown').contains(e.target)) {
    searchOptions.style.display = 'none';
  }
});





function saveSettings() {
  const newSettings = {
    newtabclockform: clockToggle.checked ? '24' : '12',
    wallpaperEnabled: wallpaperToggle.checked,
    bookmarksuggestions: bookmarksuggestionsToggle.checked
  };
  localStorage.setItem('ntabsettings', JSON.stringify(newSettings));
}

function saveSettingswithrefresh() {
  saveSettings();  localStorage.latest = generateTimestamp();

}

clockToggle.addEventListener('change', saveSettings);
wallpaperToggle.addEventListener('change', saveSettings);
bookmarksuggestionsToggle.addEventListener('change', saveSettingswithrefresh);




async function exportData() {
      const allData = {
        localStorage: { ...localStorage },
        indexedDB: {}
      };

      const dbs = await indexedDB.databases();
      for (const dbInfo of dbs) {
        if (!dbInfo.name) continue;
        const dbExport = await exportIndexedDB(dbInfo.name);
        allData.indexedDB[dbInfo.name] = dbExport;
      }

      const blob = new Blob([JSON.stringify(allData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'backup_data.heck';
      a.click();
      URL.revokeObjectURL(url);

      setTimeout(() => {
        window.close();
      }, 1000);
    }

    function exportIndexedDB(name) {
      return new Promise((resolve) => {
        const openRequest = indexedDB.open(name);
        openRequest.onsuccess = () => {
          const db = openRequest.result;
          const tx = db.transaction(db.objectStoreNames, 'readonly');
          const exportObject = {};
          let pendingStores = db.objectStoreNames.length;

          if (pendingStores === 0) return resolve({});

          for (const storeName of db.objectStoreNames) {
            const store = tx.objectStore(storeName);
            const getAll = store.getAll();
            getAll.onsuccess = () => {
              exportObject[storeName] = getAll.result;
              if (--pendingStores === 0) resolve(exportObject);
            };
            getAll.onerror = () => {
              exportObject[storeName] = [];
              if (--pendingStores === 0) resolve(exportObject);
            };
          }
        };
        openRequest.onerror = () => resolve({});
      });
    }

    async function importData(data) {
      for (const key in data.localStorage) {
        localStorage.setItem(key, data.localStorage[key]);
      }

      for (const dbName in data.indexedDB) {
        await importIndexedDB(dbName, data.indexedDB[dbName]);
      }

        localStorage.latest = generateTimestamp();
          setTimeout(() => {
        window.close();
      }, 100);

    }

    function importIndexedDB(name, dbData) {
      return new Promise((resolve) => {
        const req = indexedDB.open(name, 1);
        req.onupgradeneeded = () => {
          const db = req.result;
          for (const storeName in dbData) {
            if (!db.objectStoreNames.contains(storeName)) {
              db.createObjectStore(storeName, { autoIncrement: true });
            }
          }
        };
        req.onsuccess = () => {
          const db = req.result;
          const tx = db.transaction(Object.keys(dbData), 'readwrite');
          for (const storeName in dbData) {
            const store = tx.objectStore(storeName);
            for (const item of dbData[storeName]) {
              store.add(item);
            }
          }
          tx.oncomplete = () => resolve();
        };
        req.onerror = () => resolve();
      });
    }

    async function clearAllData() {
      localStorage.clear();
      indexedDB.databases().then(dbs => {
  dbs.forEach(db => {
    indexedDB.deleteDatabase(db.name);
  });
});
  localStorage.latest = generateTimestamp();

            setTimeout(() => {
        window.close();
      }, 100);

    }

    document.getElementById('exportBtn').onclick = exportData;
document.getElementById('reporter').onclick = () => window.open('http://heckthetech.github.io/report');
document.getElementById('heckabt').onclick = () => window.open('http://heckthetech.github.io/');

    document.getElementById('fileInput').addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const data = JSON.parse(reader.result);
          importData(data);
        } catch (err) {
          alert("Invalid file, make sure you have chosen correct .heck backup file!");
        }
      };
      reader.readAsText(file);
    });

    document.getElementById('clearBtn').onclick = () => {
      if (confirm("This will delete ALL data , Search History and Plugins. Continue?")) {
        clearAllData();
      }
    };

fetch('/manifest.json')
  .then(response => response.json())
  .then(data => {
    const versionElement = document.getElementById("version");
    const noteElement = document.getElementById("versionnote");

    if (versionElement) versionElement.textContent = data.version || "N/A Invalid";
    if (noteElement) noteElement.textContent = data.versionnote || "Invalid Source";
  })
  .catch(err => {
    console.error("Failed to load version data:", err);
  });

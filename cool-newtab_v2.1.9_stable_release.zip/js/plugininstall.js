const DELIM = "////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////";
const DB_NAME = "plugindata";
const STORE_NAME = "plugins";
const KEY_NAME = "all";

let pluginCode = "";
let pluginMeta = { name: "", version: "", author: "" };
function generateTimestamp() {
  const now = new Date();
  const day = now.toLocaleDateString(undefined, { weekday: 'long' });
  return (
    now.getFullYear().toString() +
    (now.getMonth() + 1).toString().padStart(2, '0') +
    now.getDate().toString().padStart(2, '0') +
    now.getHours().toString().padStart(2, '0') +
    now.getMinutes().toString().padStart(2, '0') +
    now.getSeconds().toString().padStart(2, '0') +
    day
  );
}

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => resolve(req.result);
    req.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
  });
}

function base64ToText(base64) {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return new TextDecoder("utf-8").decode(bytes);
}

function base64ToImageSrc(base64) {
  return "data:image/png;base64," + base64;
}

function parsePluginMeta(text) {
  const firstLine = text.split('\n')[0] || "";
  const regex = /pluginname\{([^}]+)\}version\{([^}]+)\}Author\{([^}]+)\}/i;
  const match = firstLine.match(regex);
  if (match) {
    return {
      name: match[1].trim(),
      version: match[2].trim(),
      author: match[3].trim()
    };
  }
  return { name: "", version: "", author: "" };
}

async function getInstalledPlugins() {
  const db = await openDB();
  const tx = db.transaction(STORE_NAME, "readonly");
  const store = tx.objectStore(STORE_NAME);
  return new Promise((resolve, reject) => {
    const getReq = store.get(KEY_NAME);
    getReq.onsuccess = () => {
      if (getReq.result) {
        const plugins = getReq.result.split(DELIM);
        const metas = plugins.map(p => parsePluginMeta(p));
        resolve(metas);
      } else {
        resolve([]);
      }
    };
    getReq.onerror = () => reject(getReq.error);
  });
}

function compareVersions(v1, v2) {
  // Normalize: split and convert each part to number, ignoring trailing zeros
  const a = v1.split('.').map(x => Number(x));
  const b = v2.split('.').map(x => Number(x));
  const maxLen = Math.max(a.length, b.length);
  for (let i = 0; i < maxLen; i++) {
    const na = a[i] || 0;
    const nb = b[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}

async function checkPluginStatus(meta) {
  const installed = await getInstalledPlugins();

  console.log(`Checking plugin status for: ${meta.name} v${meta.version} by ${meta.author}`);

  for (const p of installed) {
    if (p.name === meta.name && p.author === meta.author) {
      console.log(`Installed plugin: ${p.name} v${p.version} by ${p.author}`);

      const cmp = compareVersions(meta.version, p.version);
      console.log(`Version compare result: ${cmp}`);

      if (cmp === 0) return "installed";
      if (cmp > 0) return "update";
      if (cmp < 0) return "older";
    }
  }
  return "new";
}

async function saveToPluginDB() {
  const db = await openDB();
  const tx = db.transaction(STORE_NAME, "readwrite");
  const store = tx.objectStore(STORE_NAME);

  const existing = await new Promise((resolve, reject) => {
    const getReq = store.get(KEY_NAME);
    getReq.onsuccess = () => resolve(getReq.result);
    getReq.onerror = () => reject(getReq.error);
  });

  const plugins = existing ? existing.split(DELIM) : [];

  let replaced = false;
  for (let i = 0; i < plugins.length; i++) {
    const pMeta = parsePluginMeta(plugins[i]);
    if (pMeta.name === pluginMeta.name && pMeta.author === pluginMeta.author) {
      plugins[i] = pluginCode;
      replaced = true;
      break;
    }
  }

  if (!replaced) {
    plugins.push(pluginCode);
  }

  return new Promise((resolve, reject) => {
    const putReq = store.put(plugins.join(DELIM), KEY_NAME);
    putReq.onsuccess = () => resolve();
    putReq.onerror = () => reject(putReq.error);
  });
}

function updateInstallButton(status) {
  const btn = document.getElementById("installBtn");
  if (!btn) {
    console.warn("Install button not found");
    return;
  }

  if (status === "installed") {
    document.getElementById("actions").innerHTML = "Already Installed the latest version";
    chrome.storage.local.remove(["lastFileContent", "lastFileName", "lastFileLogo"]);
    localStorage.latest = generateTimestamp();
  } else if (status === "update") {
    btn.textContent = "Update";
    btn.disabled = false;
  } else if (status === "older") {
    btn.textContent = "Downgrade (Installed Newer)";
    btn.disabled = false;
    chrome.storage.local.remove(["lastFileContent", "lastFileName", "lastFileLogo"]);
  } else {
    btn.textContent = "Install";
    btn.disabled = false;
    chrome.storage.local.remove(["lastFileContent", "lastFileName", "lastFileLogo"]);
  }
}

function startInstall() {
  document.getElementById("actions").style.display = "none";
  document.getElementById("progressBarContainer").style.display = "block";
  const bar = document.getElementById("progressBar");
  const status = document.getElementById("status");

  let progress = 0;
  const interval = setInterval(() => {
    progress += Math.random() * 36;
    if (progress >= 100) {
      progress = 100;
      clearInterval(interval);
      saveToPluginDB().then(() => {
        status.textContent = "✔ Plugin installed!";
        bar.style.background = "#1274ecff";
        chrome.storage.local.remove(["lastFileContent", "lastFileName", "lastFileLogo"]);
        localStorage.latest = generateTimestamp();
      }).catch(err => {
        status.textContent = "❌ Error: " + err.message;
        bar.style.background = "#f44336";
      });
    }
    bar.style.width = progress + "%";
  }, 200);
}

function cancel() {
  document.getElementById("status").textContent = "❌ Installation cancelled.";
  document.getElementById("actions").style.display = "none";
  localStorage.latest = generateTimestamp();
}

chrome.storage.local.get(["lastFileContent", "lastFileName", "lastFileLogo"], async data => {
  if (data.lastFileContent) {
    try {
      console.log("Raw base64 plugin data:", data.lastFileContent);
      pluginCode = base64ToText(data.lastFileContent);
      console.log("Decoded plugin code:", pluginCode);
      pluginMeta = parsePluginMeta(pluginCode);
      console.log("Parsed plugin meta:", pluginMeta);

      document.getElementById("filename").textContent = pluginMeta.name || data.lastFileName || "Unnamed Plugin";
      document.getElementById("logo").src = data.lastFileLogo
        ? base64ToImageSrc(data.lastFileLogo)
        : "https://dummyimage.com/64x64/333/fff.png&text=📦";
document.getElementById("logo").style.display = "";
      const status = await checkPluginStatus(pluginMeta);
      console.log("Plugin install status:", status);
      updateInstallButton(status);

      document.getElementById("actions").style.display = "block";
      document.getElementById("progressBarContainer").style.display = "none";
      document.getElementById("status").textContent = "";
    } catch (err) {
      console.error("Error decoding plugin:", err);
      document.getElementById("status").textContent = "❌ Error decoding plugin.";
      document.getElementById("actions").style.display = "none";
      document.getElementById("progressBarContainer").style.display = "none";
    }
  } else {
    document.getElementById("actions").style.display = "none";
    document.getElementById("progressBarContainer").style.display = "none";
  }
});

document.getElementById("installBtn").onclick = startInstall;
document.getElementById("cancelBtn").onclick = cancel;

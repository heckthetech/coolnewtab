window.location.replace("/newtab.html");
//Microsoft Edge's default behavior automatically focuses the address bar on the new tab page.
//This behavior is controlled by the browser and cannot be programmatically overridden or modified through scripts. 
// As a result, attempts to change or disable this auto-focus, including via JavaScript, will not be effective. 
// The included script window.location.replace("newtab.html"); will not affect this behavior by redirecting once.


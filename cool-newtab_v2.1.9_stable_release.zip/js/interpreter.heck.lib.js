//Heck Plugin Language Interpreter Library Version 4

function interpret(code, full = true) {
  if (full) {
    if (!window.hasClearedOutput) {
      output.innerHTML = "";
      window.hasClearedOutput = true;
    }
    lastScript = code;
  }

  const lines = code.split("\n");
let i = 0;

// Get plugin name once for this code
let currentPluginName = "unknown";
const metaLine = lines.find(l => l.startsWith("//pluginname{"));
const match = metaLine && metaLine.match(/\/\/\s*pluginname\{([^}]*)\}/);
if (match) currentPluginName = match[1].trim();


  while (i < lines.length) {
    const raw = lines[i].trim();
    if (!raw || raw.startsWith("//") || raw === "}" || raw === "^^;") {
      i++;
      continue;
    }

// —— CSS Block ——
if (raw.startsWith("set override css = ^^")) {
  i++;
  let css = "";
  while (i < lines.length && !lines[i].trim().startsWith("^^;")) {
    css += lines[i++] + "\n";
  }

  const safeId = "for-" + currentPluginName.replace(/[^a-z0-9]/gi, "-").toLowerCase();
  let tag = document.getElementById(safeId);
  if (!tag) {
    tag = document.createElement("style");
    tag.id = safeId;
    output.appendChild(tag);
  }
  tag.textContent = css;

  i++;
  continue;
}



    // —— Storage Commands ——
    if (raw.startsWith("default localstorage.")) {
      let [k, v] = raw.replace("default localstorage.", "").replace(/;$/, "").split("=");
      if (localStorage.getItem(k.trim()) === null) localStorage.setItem(k.trim(), v.trim());
      i++;
      continue;
    }

    if (raw.startsWith("set localstorage.")) {
      let [k, v] = raw.replace("set localstorage.", "").replace(/;$/, "").split("=");
      k = k.trim();
      v = v.trim();
      if (v.startsWith("getvalue(#")) {
        const match = v.match(/getvalue\(#(.+?)\)/);
        if (match) {
          const val = document.getElementById(match[1])?.value || "";
          localStorage.setItem(k, val);
        }
      } else {
        localStorage.setItem(k, v);
      }
      i++;
      continue;
    }

    if (raw.startsWith("inc localstorage.")) {
      const k = raw.replace("inc localstorage.", "").replace(/;$/, "").trim();
      localStorage.setItem(k, String((+localStorage.getItem(k) || 0) + 1));
      i++;
      continue;
    }

    if (raw.startsWith("dec localstorage.")) {
      const k = raw.replace("dec localstorage.", "").replace(/;$/, "").trim();
      localStorage.setItem(k, String((+localStorage.getItem(k) || 0) - 1));
      i++;
      continue;
    }

    if (raw.startsWith("reset localstorage.")) {
      const k = raw.replace("reset localstorage.", "").replace(/;$/, "").trim();
      localStorage.setItem(k, "0");
      i++;
      continue;
    }

    // —— HTML Block ——
    if (raw.startsWith("create div with id(")) {
      const id = (raw.match(/\(#(.+?)\)/) || [])[1];
      i++;
      let html = "";
      while (i < lines.length && !lines[i].trim().startsWith("^^;")) {
        html += lines[i++] + "\n";
      }
      i++;

      const existing = document.getElementById(id);
      if (existing) output.removeChild(existing);

      const container = document.createElement("div");
      container.id = id;
      container.style.position = "relative";

      html = html.replace(/loadtextfrom\(localstorage\.([^)]+)\)/g, (_, key) => localStorage.getItem(key) || '');

      html = html.replace(/loadtextfrom\(date\.format="(.+?)"\)/g, (_, fmt) => {
        const now = new Date();
        const tokens = {
          dd: String(now.getDate()).padStart(2, "0"),
          mm: String(now.getMonth() + 1).padStart(2, "0"),
          yyyy: now.getFullYear(),
          yy: String(now.getFullYear()).slice(2),
          mtext: now.toLocaleString(undefined, { month: "long" }),
          mtxt: now.toLocaleString(undefined, { month: "short" }),
          dayname: now.toLocaleString(undefined, { weekday: "long" }),
          day: now.toLocaleString(undefined, { weekday: "short" })
        };
        return fmt.split(/(\b(?:dd|mm|yyyy|yy|mtext|mtxt|dayname|day)\b)/g).map(t => tokens[t] || t).join("");
      });

      container.innerHTML = html;
      output.appendChild(container);

// —— Editable Text with Persistence ——
const editables = container.querySelectorAll('[edit="stored"]');
editables.forEach(el => {
  el.contentEditable = "true";
  const parentId = container.id || "unknown";
  const key = `${parentId}text${el.id}`;
  const savedText = localStorage.getItem(key);
  if (savedText) el.innerText = savedText;

  el.addEventListener("input", () => {
    localStorage.setItem(key, el.innerText);
  });
});


      // Restore drag
      const savedPos = localStorage.getItem(`drag_${id}`);
      if (savedPos) {
        const [x, y] = savedPos.split(",").map(n => parseInt(n, 10));
        const rect = container.getBoundingClientRect();
        container.style.position = "absolute";
        container.style.left = x + "px";
        container.style.top = y + "px";
      }

      const draggables = container.querySelectorAll("[dragmovable]");
      draggables.forEach(handle => {
        handle.style.cursor = "grab";
        let offsetX = 0, offsetY = 0, adjustX = 0, adjustY = 0;
        let shouldStore = false;
        const attr = handle.getAttribute("dragmovable");
        if (attr && attr !== "") {
          const parts = attr.split(",").map(p => p.trim());
          if (parts.length >= 2) {
            adjustX = parseInt(parts[0], 10);
            adjustY = parseInt(parts[1], 10);
          }
          if (parts.includes("stored")) {
            shouldStore = true;
          }
        }

        handle.addEventListener("mousedown", e => {
          const parent = container;
          if(!document.getElementById("forcedstyleaaa")){const styleTag = document.createElement('style');styleTag.id = 'forcedstyleaaa';document.head.appendChild(styleTag);}

          const style = document.getElementById('forcedstyleaaa');
          style.textContent = `* { user-select: none !important; -webkit-user-drag: none !important; }`;

          parent.style.position = "absolute";
          offsetX = e.clientX - parent.offsetLeft - adjustX;
          offsetY = e.clientY - parent.offsetTop - adjustY;
          document.addEventListener("mousemove", onMouseMove);
          document.addEventListener("mouseup", onMouseUp);

          function onMouseMove(ev) {
            const x = ev.clientX - offsetX;
            const y = ev.clientY - offsetY;
            const rect = parent.getBoundingClientRect();
            if (x >= 15 && x <= window.innerWidth - (rect.width + 15)) parent.style.left = x + "px";
            if (y >= 15 && y <= window.innerHeight - (rect.height + 10)) parent.style.top = y + "px";
            if (shouldStore) localStorage.setItem(`drag_${id}`, `${parseInt(parent.style.left)},${parseInt(parent.style.top)}`);
          }

          function onMouseUp() {
            document.removeEventListener("mousemove", onMouseMove);
            document.removeEventListener("mouseup", onMouseUp);
            const forced = document.getElementById("forcedstyleaaa");
            if (forced) document.getElementById("forcedstyleaaa").innerHTML ="";
          }
        });
      });
      continue;
    }

    // —— Event Listeners ——
    if (raw.startsWith("create eventlistener-on(")) {
      const parts = raw.match(/create eventlistener-on\(\s*(#[^)]+)\s*\)-doing\^\^/);
      const selector = parts && parts[1];
      i++;
      let listenerBlock = "";
      while (i < lines.length && !lines[i].trim().startsWith("^^;")) {
        const ln = lines[i++].trim();
        if (!ln || ln.startsWith("//")) continue;
        listenerBlock += ln + "\n";
      }
      i++;

      const el = document.querySelector(selector);
      if (el) {
        el.addEventListener("click", () => {
          interpret(listenerBlock, false);
        });
      }
      continue;
    }

    // —— Search Widget ——
    if (raw.startsWith("create searcher for-")) {
      const m = raw.match(
        /create searcher for-\(\s*(.+?)\s*\)-inputid\(\s*(#[^)]+)\s*\)-buttonid\(\s*(#[^)]+)\s*\)/
      );
      if (m) {
        const [, urlTpl, inpSel, btnSel] = m;
        const btn = document.querySelector(btnSel);
        const inp = document.querySelector(inpSel);
        if (btn && inp) {
          btn.addEventListener("click", () => {
            const q = encodeURIComponent(inp.value.trim());
            const url = urlTpl.replace("!!gettextfrominputid!!", q);
            window.location.replace(url);
          });
        }
      }
      i++;
      continue;
    }
console.log(
  "%c⚠️ Not a function: %c" + raw,
  " color: #ff4d6d; font-size: 13px; font-family: Calibri; font-weight: bold; background: #1e1e1e; padding: 6px 10px; border-left: 4px solid #ff4d6d;",
    "color:rgb(254, 151, 171); font-size: 13px; font-family: monospace; font-weight: bold; background:rgb(46, 46, 46); padding: 6px 10px; border-bottom: 4px solid #ff4d6d;"
);

    i++;
  }
}
